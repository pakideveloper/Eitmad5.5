<?php

$dbhost = "localhost";
$user_acc="root";
$user_pass= "";
$database = "studentsdb";
//print_r($_POST);
$conn = mysqli_connect($dbhost, $user_acc, $user_pass,$database);
if (!$conn){
    die("mysqli could not connect".  mysqli_error());
}


?>