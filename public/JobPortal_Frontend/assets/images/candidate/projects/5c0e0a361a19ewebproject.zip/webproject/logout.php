<?php
session_start();
session_destroy();
//header('location:login.php?logout=You have been logout....!');
echo "<script>window.open('login.php?logout=You have been logout....!','_self')</script>";

?>
e