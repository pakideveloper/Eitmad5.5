
<html>
    <head>
        <title>
            HTML web Page by Bilal Ahmed
        </title>
        <link rel="stylesheet" type="text/css" href="style.css">


        </head>
        <body>
            <div class="header"><h3 style="text-align: left;">  </h3>  
                  <h1> Student Registration System</h1>
                <h1>  <a href="#" > Bilal Ahmed: ROLL# 13 MCS  </a> </h1>  

        </div>
        <hr>
        <div class="nav_bar"> 
            <a href="index.php">&nbsp; Home &nbsp;</a>
             <a href="view.php">&nbsp; View &nbsp; </a>  
            <a href="contact.php">&nbsp; Contact &nbsp; </a>
               <a href="login.php">&nbsp; Login &nbsp; </a>
               
        </div>
        <div class="cont">  
            <h2> Registration Form</h2>
            <form action="processForm.php" method="post">
            <table>
                <tr>
                    <td>  Student Name</td>
                    <td><input type="text" name="studentName" > </td>

                </tr>
                <tr>
                    <td> Father Name</td>
                    <td><input type="text" name="fatherName" ></td>

                </tr>

                <tr>
                    <td>Email</td>
                    <td><input type="email" name="email" ></td>

                </tr>

                <tr>
                    <td>Password</td>
                    <td><input type="password" name="pass" ></td>

                </tr>
                <tr>
                    <td>Date of Birth</td>
                    <td><input type="date" name="dob" ></td>

                </tr>
                <tr>
                    <td>Class Name</td>
                    <td><input type="text" name="className" ></td>

                </tr>
                <tr> 
                    <td>
                        <label> Select Gender : </label>  &nbsp;  </td>
                    <td> <input type="radio" id="" name="gender" value="male">Male

                        <input type="radio" id="" name="gender" value="female">   Female<br> <br> 
                    </td>
                </tr>
                <tr>
                    <td> <label> Area of Interests  : </label>  &nbsp; </td>
                    <td>  <input type="checkbox"  id="" name="interests" class="chkbox1" value="movies"  > Movies
                        <input type="checkbox" id="" name="interests" class="chkbox2" value="sports"  > Sports  <br><br> 
                    </td>
                </tr>

                <tr>
                    <td> Select City :  </td>
                    <td> <select required="true" name="city" > 
                            <option> Select One option </option>
                            <option> Lahore </option>
                            <option> Karachi </option>
                            <option> Multan </option>
                            <option> Gujrat </option>
                        </select> </td>
                </tr>
               <!-- <tr>
                    <td> Your Image</td>
                    <td><input type="file" name="img" ></td>

                </tr> -->
                <tr>

                    <td colspan="2" style="text-align: center;"><input type="submit" name="sub" value="Submit" ></td>

                </tr>

            </table> 
            </form>

        </div>

        <div class="footer">
            <h3>This is Footer </h3> 
        </div>
    </body>

</html>