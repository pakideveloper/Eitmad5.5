<?php

include 'connection.php';
$del=$_GET['del'];
$res=  mysqli_query($conn,"delete from registration where id=$del");
echo "<script>window.open('view.php?deleted=Record Has been Deleted Successfuly','_self')</script>";

?>