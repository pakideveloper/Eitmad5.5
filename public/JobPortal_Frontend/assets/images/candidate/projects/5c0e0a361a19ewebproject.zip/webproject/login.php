<?php 
session_start();
?>
<html>
    <head>
   <style>
       #login_box{
         height: 300px; width: 350px; line-height:47px;vertical-align: central;
         border:4px solid black;  margin: auto; text-align: center;
         color: black;font-size:18px
       } 
      input{
           height: 30px;
           

       }
       
       
   </style>
        
    </head>
    <body>

    <div id="login_box">
<form action="login.php" method="post">
    
    Enter Email:<br>
    <input type='email' name='user_email' required="required"> <br>
    Enter Password:<br>
    <input type='password' name='user_password' required="required"><br>
           
    	<input type='submit' name='submit' value='Login' size="20">
    
</form>
  


<?php
include 'connection.php';

if(isset($_POST['submit'])){
    
    $user_email = $_POST['user_email'];
    $user_pass = ($_POST['user_password']);
    
    
    $selectquery  = mysqli_query($conn, "select email,password from registration where email='$user_email'"
            . "and password='$user_pass'");
    if(mysqli_num_rows($selectquery) == 0){
        echo "<center><font style='color:red;font-size:20px;'>"
        . "User Name OR Password is Incorect </font></center>";
    }
    
    elseif(mysqli_num_rows($selectquery) == 1){ 
       while ($row = mysqli_fetch_array($selectquery)) {
         
             $studentEmail = $row['email'];
            $studentPass = $row['password']; 
            
            }
            if($studentEmail == $user_email ){
                
                $_SESSION['user_email'] = $user_email;
                $_SESSION['user_password'] = $user_pass;
             echo "<script>window.open('view.php?loggedin=You have logged in successfully..!','_self')</script>";
                   
            }
   
  
          
            }
         ?>
      
    <?php  
           if(isset($_GET['logout'])){
            $logout=$_GET['logout'];
            echo '<h2>'.$logout.'</h2>';
}
     
    
}
    ?>
    </div>
  </body>
</html>








