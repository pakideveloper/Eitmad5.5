

<html>
    <body>  
        <?php //include 'admin.php'; ?>
        <?php
        include 'connection.php';
        if (isset($_GET['edit_record'])) {
            echo '<pre>';
          //  print_r($_GET);
            echo '</pre>';
            $edit_id = $_GET['edit_record'];
            $res = mysqli_query($conn, "select * from registration where id='$edit_id'");

            while ($row = mysqli_fetch_array($res)) {
    $db_id = $row['id'];
    $db_st_name = $row['name'];
    $db_father_name = $row['father_name'];
    $db_st_email = $row['email'];
    $db_st_pass = $row['password'];
    $db_st_dob = $row['dob'];
    $db_st_class = $row['class'];
    $db_st_gender = $row['gender'];
    $db_st_interests = $row['interests'];
    $db_st_city = $row['city'];
            }
            ?>


            <form action="edit.php?update_record=<?php echo $db_id; ?>" method="post" enctype="multipart/form-data">
                <table border="2" width="600" align="center">
                    <tr >
                        <td colspan="2" bgcolor="lightblue"align="center"><h2>Edit/Update Product's Detail</h2></td>

                    </tr>
                    <tr>
                        <td>Student Name</td>
                        <td><input type="text" name="studentName" value="<?php echo $db_st_name; ?>" 
                                   required="required"></td>
                    </tr>

                    <tr>
                        <td>Father Name</td>
                        <td><input type="text" name="fatherName" value="<?php echo $db_father_name; ?>"  required="required">

                        </td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><input type="text" name="email" value="<?php echo $db_st_email; ?>"required="required"></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td><input type="text" name="pass" value="<?php echo $db_st_pass; ?>" required="required"></td>
                    </tr>
                    <tr>
                        <td>Date of Birth</td>
                        <td><input type="text" name="dob" value="<?php echo $db_st_dob; ?>" required="required"></td>
                    </tr>
                    <tr>
                        <td>Class Name</td>
                        <td align="center"><input type="text" name="className" required="required" value="<?php echo $db_st_class; ?>" ></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td align="center"><input type="text" name="gender" required="required" value="<?php echo $db_st_gender; ?>" ></td>
                    </tr>
                    <tr>
                        <td>Interests</td>
                        <td align="center">
                            <input type="text" name="interests" required="required" value="<?php echo $db_st_interests; ?>" >
                            
                        </td>
                    </tr>
                    <tr>
                        <td>City</td>
                        <td align="center"> 
                            
                    
                            <!--<input type="text" name="city" required="required" value="<?php echo $db_st_city; ?>" >-->
                          <select required="true" name="city" > 
                              <option value="<?php echo $db_st_city; ?>"> <?php echo $db_st_city; ?></option>
                              <option value="Lahore"> Lahore </option>
                              <option value="Karachi"> Karachi </option>
                              <option value="Multan"> Multan </option>
                              <option value="Gujrat"> Gujrat </option>
                        </select>
                        
                        </td>
                    </tr>
                    <tr>

                        <td colspan="2" align="center"><input type="submit" name="update" value="Update"></td>
                    </tr>
                </table>
            </form>



        </body>
    </html> 


    <?php
}
if (isset($_POST['update'])) {

    $update_id = $_GET['update_record'];
    $st_name = $_POST['studentName'];
    $father_name = $_POST['fatherName'];
    $st_email = $_POST['email'];
    $st_pass = $_POST['pass'];
    $st_dob = $_POST['dob'];
    $st_class = $_POST['className'];
    $st_gender = $_POST['gender'];
    $st_interests = $_POST['interests'];
    $st_city = $_POST['city'];
    
    $res = mysqli_query($conn, "update registration set name='$st_name',father_name='$father_name',email='$st_email',"
            . "password='$st_pass',dob='$st_dob', class='$st_class',gender='$st_gender', interests='$st_interests',"
            . "city='$st_city' where id='$update_id'");
    if ($res == TRUE) {

        echo"<script>window.open('view.php?updated=Post Has Been Updated','_self')</script>";
    } else {
        echo mysqli_error($conn);
        echo '<br>Error No is:' . mysqli_errno($conn);
    }
}
?>