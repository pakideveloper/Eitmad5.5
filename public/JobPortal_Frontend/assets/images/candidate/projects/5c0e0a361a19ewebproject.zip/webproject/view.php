<?php 
session_start();
if(!$_SESSION['user_email'] ){
    header("Location:login.php");
}
?>
<html>
    <head>
        <title>
            HTML web Page by Bilal Ahmed
        </title>
        <link rel="stylesheet" type="text/css" href="style.css">


        </head>
        <style>
            table{
                width: 800px; 
            }
            th {
                border:2px solid black; padding: 15px;
            }
            td{
                color: black; 
            }
            .menu_bar{
              height: 40px; background-color: purple; color: white; 
              text-align: right; vertical-align: central; 
            }
            .menu_bar a{
             color: white; text-align: right; font-weight: bolder;  padding: 15px; margin-right: 100px; vertical-align: central;
            }
        </style>
        <body>
         <?php
         if(isset($_GET['deleted'])){
            $deleted=$_GET['deleted'];
            echo '<h2>'.$deleted.'</h2>';
}
        if(isset($_GET['updated'])){
            $updated=$_GET['updated'];
            echo '<h2>'.$updated.'</h2>';
}
        if(isset($_GET['loggedin'])){
            $loggedin=$_GET['loggedin'];
            echo '<h2>'.$loggedin.'</h2>';
}
?>
            <div class="menu_bar"> <a href="logout.php">Logout</a> </div>
            <div class="nav_bar"> 
            <a href="index.php">&nbsp; Home &nbsp;</a>
             <a href="view.php">&nbsp; View &nbsp; </a>  
            <a href="contact.php">&nbsp; Contact &nbsp; </a>
               <a href="login.php">&nbsp; Login &nbsp; </a>
               
        </div>
  <table >
    <tr>
        <th >ID</th>
        <th >Student Name</th>
        <th >Father Name</th>
        <th >Email</th>
        <th >Password</th>
        <th >Date of Birth</th>
        <th >class</th>
        <th >Gender</th>
        <th >Interests</th>
        <th >City</th>
        <th >Update</th>
        <th >Delete</th>
        
    </tr>          
<?php

require_once 'connection.php';

$select_query = mysqli_query($conn, "select * from registration");
while ($row = mysqli_fetch_array($select_query)) {
    $db_id = $row['id'];
    $db_st_name = $row['name'];
    $db_father_name = $row['father_name'];
    $db_st_email = $row['email'];
    $db_st_pass = $row['password'];
    $db_st_dob = $row['dob'];
    $db_st_class = $row['class'];
    $db_st_gender = $row['gender'];
    $db_st_interests = $row['interests'];
    $db_st_city = $row['city'];
    ?>

    <tr>
        <td ><?php echo $db_id;?></td>
        <td ><?php echo $db_st_name;?></td>
        <td><?php echo $db_father_name;?></td>
        <td><?php echo $db_st_email;?></td>
        <td><?php echo $db_st_pass;?></td>
        <td><?php echo $db_st_dob;?></td>
        <td><?php echo $db_st_class;?></td>
        <td><?php echo $db_st_gender;?></td>
        <td><?php echo $db_st_interests;?></td>
        <td><?php echo $db_st_city;?></td>
        <td ><a href="edit.php?edit_record=<?php echo $db_id ; ?>">edit/Update</a></td>
        <td ><a href="delete.php?del=<?php echo $db_id ; ?>">Delete</a></td>
    </tr>
    

    
    
  <?php  
}

?>
    </table>
        </body>
</html>