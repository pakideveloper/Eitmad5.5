<?php
require_once 'connection.php';

if(isset($_POST['sub'])){
    $st_name = $_POST['studentName'];
    $father_name = $_POST['fatherName'];
    $st_email = $_POST['email'];
    $st_pass = $_POST['pass'];
    $st_dob = $_POST['dob'];
    $st_class = $_POST['className'];
    $st_gender = $_POST['gender'];
    $st_interests = $_POST['interests'];
    $st_city = $_POST['city'];
    
    
    
    $query = mysqli_query($conn, "insert into registration (name,father_name,email,password,dob,class,gender,interests,city) "
            . "values ('$st_name','$father_name','$st_email','$st_pass','$st_dob','$st_class','$st_gender','$st_interests','$st_city')");
}


?>
